﻿
namespace DataBinding_Sarmiento
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.studIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.middleNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.birthdayDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.programDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sectionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.yearLevelDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tblStudentInfoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.studentsDataSet = new DataBinding_Sarmiento.studentsDataSet();
            this.bSCSToolStrip = new System.Windows.Forms.ToolStrip();
            this.bSCSToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.tblStudent_InfoTableAdapter = new DataBinding_Sarmiento.studentsDataSetTableAdapters.tblStudent_InfoTableAdapter();
            this.bSIT_StudentsToolStrip = new System.Windows.Forms.ToolStrip();
            this.bSIT_StudentsToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.address_SamalToolStrip = new System.Windows.Forms.ToolStrip();
            this.address_SamalToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.second_Year_StudentsToolStrip = new System.Windows.Forms.ToolStrip();
            this.second_Year_StudentsToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.lastnames_Start_with_A_and_CToolStrip = new System.Windows.Forms.ToolStrip();
            this.lastnames_Start_with_A_and_CToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.firstnames_Start_with_Consotant_LettersToolStrip = new System.Windows.Forms.ToolStrip();
            this.firstnames_Start_with_Consotant_LettersToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.section_2BToolStrip = new System.Windows.Forms.ToolStrip();
            this.section_2BToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.rEFRESH1ToolStrip = new System.Windows.Forms.ToolStrip();
            this.rEFRESH1ToolStripButton = new System.Windows.Forms.ToolStripButton();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentInfoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentsDataSet)).BeginInit();
            this.bSCSToolStrip.SuspendLayout();
            this.bSIT_StudentsToolStrip.SuspendLayout();
            this.address_SamalToolStrip.SuspendLayout();
            this.second_Year_StudentsToolStrip.SuspendLayout();
            this.lastnames_Start_with_A_and_CToolStrip.SuspendLayout();
            this.firstnames_Start_with_Consotant_LettersToolStrip.SuspendLayout();
            this.section_2BToolStrip.SuspendLayout();
            this.rEFRESH1ToolStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Black;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Yellow;
            this.label1.Location = new System.Drawing.Point(144, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(513, 36);
            this.label1.TabIndex = 0;
            this.label1.Text = "Student Records Monitoring System";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.PaleTurquoise;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.studIDDataGridViewTextBoxColumn,
            this.lastNameDataGridViewTextBoxColumn,
            this.firstNameDataGridViewTextBoxColumn,
            this.middleNameDataGridViewTextBoxColumn,
            this.addressDataGridViewTextBoxColumn,
            this.birthdayDataGridViewTextBoxColumn,
            this.programDataGridViewTextBoxColumn,
            this.sectionDataGridViewTextBoxColumn,
            this.yearLevelDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tblStudentInfoBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(44, 57);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(718, 279);
            this.dataGridView1.TabIndex = 1;
            // 
            // studIDDataGridViewTextBoxColumn
            // 
            this.studIDDataGridViewTextBoxColumn.DataPropertyName = "StudID";
            this.studIDDataGridViewTextBoxColumn.HeaderText = "StudID";
            this.studIDDataGridViewTextBoxColumn.Name = "studIDDataGridViewTextBoxColumn";
            // 
            // lastNameDataGridViewTextBoxColumn
            // 
            this.lastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName";
            this.lastNameDataGridViewTextBoxColumn.HeaderText = "LastName";
            this.lastNameDataGridViewTextBoxColumn.Name = "lastNameDataGridViewTextBoxColumn";
            // 
            // firstNameDataGridViewTextBoxColumn
            // 
            this.firstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.HeaderText = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.Name = "firstNameDataGridViewTextBoxColumn";
            // 
            // middleNameDataGridViewTextBoxColumn
            // 
            this.middleNameDataGridViewTextBoxColumn.DataPropertyName = "MiddleName";
            this.middleNameDataGridViewTextBoxColumn.HeaderText = "MiddleName";
            this.middleNameDataGridViewTextBoxColumn.Name = "middleNameDataGridViewTextBoxColumn";
            // 
            // addressDataGridViewTextBoxColumn
            // 
            this.addressDataGridViewTextBoxColumn.DataPropertyName = "Address";
            this.addressDataGridViewTextBoxColumn.HeaderText = "Address";
            this.addressDataGridViewTextBoxColumn.Name = "addressDataGridViewTextBoxColumn";
            // 
            // birthdayDataGridViewTextBoxColumn
            // 
            this.birthdayDataGridViewTextBoxColumn.DataPropertyName = "Birthday";
            this.birthdayDataGridViewTextBoxColumn.HeaderText = "Birthday";
            this.birthdayDataGridViewTextBoxColumn.Name = "birthdayDataGridViewTextBoxColumn";
            // 
            // programDataGridViewTextBoxColumn
            // 
            this.programDataGridViewTextBoxColumn.DataPropertyName = "Program";
            this.programDataGridViewTextBoxColumn.HeaderText = "Program";
            this.programDataGridViewTextBoxColumn.Name = "programDataGridViewTextBoxColumn";
            // 
            // sectionDataGridViewTextBoxColumn
            // 
            this.sectionDataGridViewTextBoxColumn.DataPropertyName = "Section";
            this.sectionDataGridViewTextBoxColumn.HeaderText = "Section";
            this.sectionDataGridViewTextBoxColumn.Name = "sectionDataGridViewTextBoxColumn";
            // 
            // yearLevelDataGridViewTextBoxColumn
            // 
            this.yearLevelDataGridViewTextBoxColumn.DataPropertyName = "YearLevel";
            this.yearLevelDataGridViewTextBoxColumn.HeaderText = "YearLevel";
            this.yearLevelDataGridViewTextBoxColumn.Name = "yearLevelDataGridViewTextBoxColumn";
            // 
            // tblStudentInfoBindingSource
            // 
            this.tblStudentInfoBindingSource.DataMember = "tblStudent_Info";
            this.tblStudentInfoBindingSource.DataSource = this.studentsDataSet;
            // 
            // studentsDataSet
            // 
            this.studentsDataSet.DataSetName = "studentsDataSet";
            this.studentsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bSCSToolStrip
            // 
            this.bSCSToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.bSCSToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bSCSToolStripButton});
            this.bSCSToolStrip.Location = new System.Drawing.Point(44, 352);
            this.bSCSToolStrip.Name = "bSCSToolStrip";
            this.bSCSToolStrip.Size = new System.Drawing.Size(119, 25);
            this.bSCSToolStrip.TabIndex = 2;
            this.bSCSToolStrip.Text = "bSCSToolStrip";
            // 
            // bSCSToolStripButton
            // 
            this.bSCSToolStripButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.bSCSToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.bSCSToolStripButton.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bSCSToolStripButton.Name = "bSCSToolStripButton";
            this.bSCSToolStripButton.Size = new System.Drawing.Size(107, 22);
            this.bSCSToolStripButton.Text = "BSCS Students";
            this.bSCSToolStripButton.Click += new System.EventHandler(this.bSCSToolStripButton_Click);
            // 
            // tblStudent_InfoTableAdapter
            // 
            this.tblStudent_InfoTableAdapter.ClearBeforeFill = true;
            // 
            // bSIT_StudentsToolStrip
            // 
            this.bSIT_StudentsToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.bSIT_StudentsToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bSIT_StudentsToolStripButton});
            this.bSIT_StudentsToolStrip.Location = new System.Drawing.Point(178, 352);
            this.bSIT_StudentsToolStrip.Name = "bSIT_StudentsToolStrip";
            this.bSIT_StudentsToolStrip.Size = new System.Drawing.Size(115, 25);
            this.bSIT_StudentsToolStrip.TabIndex = 3;
            this.bSIT_StudentsToolStrip.Text = "bSIT_StudentsToolStrip";
            // 
            // bSIT_StudentsToolStripButton
            // 
            this.bSIT_StudentsToolStripButton.BackColor = System.Drawing.Color.Chartreuse;
            this.bSIT_StudentsToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.bSIT_StudentsToolStripButton.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bSIT_StudentsToolStripButton.Name = "bSIT_StudentsToolStripButton";
            this.bSIT_StudentsToolStripButton.Size = new System.Drawing.Size(103, 22);
            this.bSIT_StudentsToolStripButton.Text = "BSIT Students";
            this.bSIT_StudentsToolStripButton.Click += new System.EventHandler(this.bSIT_StudentsToolStripButton_Click);
            // 
            // address_SamalToolStrip
            // 
            this.address_SamalToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.address_SamalToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.address_SamalToolStripButton});
            this.address_SamalToolStrip.Location = new System.Drawing.Point(305, 352);
            this.address_SamalToolStrip.Name = "address_SamalToolStrip";
            this.address_SamalToolStrip.Size = new System.Drawing.Size(134, 25);
            this.address_SamalToolStrip.TabIndex = 4;
            this.address_SamalToolStrip.Text = "address_SamalToolStrip";
            // 
            // address_SamalToolStripButton
            // 
            this.address_SamalToolStripButton.BackColor = System.Drawing.Color.MediumSpringGreen;
            this.address_SamalToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.address_SamalToolStripButton.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.address_SamalToolStripButton.Name = "address_SamalToolStripButton";
            this.address_SamalToolStripButton.Size = new System.Drawing.Size(122, 22);
            this.address_SamalToolStripButton.Text = "Address Samal";
            this.address_SamalToolStripButton.Click += new System.EventHandler(this.address_SamalToolStripButton_Click);
            // 
            // second_Year_StudentsToolStrip
            // 
            this.second_Year_StudentsToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.second_Year_StudentsToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.second_Year_StudentsToolStripButton});
            this.second_Year_StudentsToolStrip.Location = new System.Drawing.Point(572, 352);
            this.second_Year_StudentsToolStrip.Name = "second_Year_StudentsToolStrip";
            this.second_Year_StudentsToolStrip.Size = new System.Drawing.Size(188, 25);
            this.second_Year_StudentsToolStrip.TabIndex = 5;
            this.second_Year_StudentsToolStrip.Text = "second_Year_StudentsToolStrip";
            // 
            // second_Year_StudentsToolStripButton
            // 
            this.second_Year_StudentsToolStripButton.BackColor = System.Drawing.Color.Magenta;
            this.second_Year_StudentsToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.second_Year_StudentsToolStripButton.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.second_Year_StudentsToolStripButton.Name = "second_Year_StudentsToolStripButton";
            this.second_Year_StudentsToolStripButton.Size = new System.Drawing.Size(176, 22);
            this.second_Year_StudentsToolStripButton.Text = "Second Year Students";
            this.second_Year_StudentsToolStripButton.Click += new System.EventHandler(this.second_Year_StudentsToolStripButton_Click);
            // 
            // lastnames_Start_with_A_and_CToolStrip
            // 
            this.lastnames_Start_with_A_and_CToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.lastnames_Start_with_A_and_CToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lastnames_Start_with_A_and_CToolStripButton});
            this.lastnames_Start_with_A_and_CToolStrip.Location = new System.Drawing.Point(44, 399);
            this.lastnames_Start_with_A_and_CToolStrip.Name = "lastnames_Start_with_A_and_CToolStrip";
            this.lastnames_Start_with_A_and_CToolStrip.Size = new System.Drawing.Size(218, 25);
            this.lastnames_Start_with_A_and_CToolStrip.TabIndex = 6;
            this.lastnames_Start_with_A_and_CToolStrip.Text = "lastnames_Start_with_A_and_CToolStrip";
            // 
            // lastnames_Start_with_A_and_CToolStripButton
            // 
            this.lastnames_Start_with_A_and_CToolStripButton.BackColor = System.Drawing.Color.LightSalmon;
            this.lastnames_Start_with_A_and_CToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.lastnames_Start_with_A_and_CToolStripButton.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lastnames_Start_with_A_and_CToolStripButton.Name = "lastnames_Start_with_A_and_CToolStripButton";
            this.lastnames_Start_with_A_and_CToolStripButton.Size = new System.Drawing.Size(206, 22);
            this.lastnames_Start_with_A_and_CToolStripButton.Text = "Lastnames Start with A and C";
            this.lastnames_Start_with_A_and_CToolStripButton.Click += new System.EventHandler(this.lastnames_Start_with_A_and_CToolStripButton_Click);
            // 
            // firstnames_Start_with_Consotant_LettersToolStrip
            // 
            this.firstnames_Start_with_Consotant_LettersToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.firstnames_Start_with_Consotant_LettersToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.firstnames_Start_with_Consotant_LettersToolStripButton});
            this.firstnames_Start_with_Consotant_LettersToolStrip.Location = new System.Drawing.Point(305, 399);
            this.firstnames_Start_with_Consotant_LettersToolStrip.Name = "firstnames_Start_with_Consotant_LettersToolStrip";
            this.firstnames_Start_with_Consotant_LettersToolStrip.Size = new System.Drawing.Size(287, 25);
            this.firstnames_Start_with_Consotant_LettersToolStrip.TabIndex = 7;
            this.firstnames_Start_with_Consotant_LettersToolStrip.Text = "firstnames_Start_with_Consotant_LettersToolStrip";
            // 
            // firstnames_Start_with_Consotant_LettersToolStripButton
            // 
            this.firstnames_Start_with_Consotant_LettersToolStripButton.BackColor = System.Drawing.Color.LightPink;
            this.firstnames_Start_with_Consotant_LettersToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.firstnames_Start_with_Consotant_LettersToolStripButton.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.firstnames_Start_with_Consotant_LettersToolStripButton.Name = "firstnames_Start_with_Consotant_LettersToolStripButton";
            this.firstnames_Start_with_Consotant_LettersToolStripButton.Size = new System.Drawing.Size(275, 22);
            this.firstnames_Start_with_Consotant_LettersToolStripButton.Text = "Firstnames Start with Consotant Letters";
            this.firstnames_Start_with_Consotant_LettersToolStripButton.Click += new System.EventHandler(this.firstnames_Start_with_Consotant_LettersToolStripButton_Click);
            // 
            // section_2BToolStrip
            // 
            this.section_2BToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.section_2BToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.section_2BToolStripButton});
            this.section_2BToolStrip.Location = new System.Drawing.Point(458, 352);
            this.section_2BToolStrip.Name = "section_2BToolStrip";
            this.section_2BToolStrip.Size = new System.Drawing.Size(96, 25);
            this.section_2BToolStrip.TabIndex = 8;
            this.section_2BToolStrip.Text = "section_2BToolStrip";
            // 
            // section_2BToolStripButton
            // 
            this.section_2BToolStripButton.BackColor = System.Drawing.Color.MediumTurquoise;
            this.section_2BToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.section_2BToolStripButton.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.section_2BToolStripButton.Name = "section_2BToolStripButton";
            this.section_2BToolStripButton.Size = new System.Drawing.Size(84, 22);
            this.section_2BToolStripButton.Text = "Section_2B";
            this.section_2BToolStripButton.Click += new System.EventHandler(this.section_2BToolStripButton_Click);
            // 
            // rEFRESH1ToolStrip
            // 
            this.rEFRESH1ToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.rEFRESH1ToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.rEFRESH1ToolStripButton});
            this.rEFRESH1ToolStrip.Location = new System.Drawing.Point(643, 398);
            this.rEFRESH1ToolStrip.Name = "rEFRESH1ToolStrip";
            this.rEFRESH1ToolStrip.Size = new System.Drawing.Size(88, 26);
            this.rEFRESH1ToolStrip.TabIndex = 9;
            this.rEFRESH1ToolStrip.Text = "rEFRESH1ToolStrip";
            // 
            // rEFRESH1ToolStripButton
            // 
            this.rEFRESH1ToolStripButton.BackColor = System.Drawing.Color.Cyan;
            this.rEFRESH1ToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.rEFRESH1ToolStripButton.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rEFRESH1ToolStripButton.Name = "rEFRESH1ToolStripButton";
            this.rEFRESH1ToolStripButton.Size = new System.Drawing.Size(76, 23);
            this.rEFRESH1ToolStripButton.Text = "Refresh";
            this.rEFRESH1ToolStripButton.ToolTipText = "REFRESH";
            this.rEFRESH1ToolStripButton.Click += new System.EventHandler(this.rEFRESH1ToolStripButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::DataBinding_Sarmiento.Properties.Resources.Cutell;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.rEFRESH1ToolStrip);
            this.Controls.Add(this.section_2BToolStrip);
            this.Controls.Add(this.firstnames_Start_with_Consotant_LettersToolStrip);
            this.Controls.Add(this.lastnames_Start_with_A_and_CToolStrip);
            this.Controls.Add(this.second_Year_StudentsToolStrip);
            this.Controls.Add(this.address_SamalToolStrip);
            this.Controls.Add(this.bSIT_StudentsToolStrip);
            this.Controls.Add(this.bSCSToolStrip);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Data Grid Sarmiento";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentInfoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentsDataSet)).EndInit();
            this.bSCSToolStrip.ResumeLayout(false);
            this.bSCSToolStrip.PerformLayout();
            this.bSIT_StudentsToolStrip.ResumeLayout(false);
            this.bSIT_StudentsToolStrip.PerformLayout();
            this.address_SamalToolStrip.ResumeLayout(false);
            this.address_SamalToolStrip.PerformLayout();
            this.second_Year_StudentsToolStrip.ResumeLayout(false);
            this.second_Year_StudentsToolStrip.PerformLayout();
            this.lastnames_Start_with_A_and_CToolStrip.ResumeLayout(false);
            this.lastnames_Start_with_A_and_CToolStrip.PerformLayout();
            this.firstnames_Start_with_Consotant_LettersToolStrip.ResumeLayout(false);
            this.firstnames_Start_with_Consotant_LettersToolStrip.PerformLayout();
            this.section_2BToolStrip.ResumeLayout(false);
            this.section_2BToolStrip.PerformLayout();
            this.rEFRESH1ToolStrip.ResumeLayout(false);
            this.rEFRESH1ToolStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private studentsDataSet studentsDataSet;
        private System.Windows.Forms.BindingSource tblStudentInfoBindingSource;
        private studentsDataSetTableAdapters.tblStudent_InfoTableAdapter tblStudent_InfoTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn studIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn middleNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn birthdayDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn programDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sectionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn yearLevelDataGridViewTextBoxColumn;
        private System.Windows.Forms.ToolStrip bSCSToolStrip;
        private System.Windows.Forms.ToolStripButton bSCSToolStripButton;
        private System.Windows.Forms.ToolStrip bSIT_StudentsToolStrip;
        private System.Windows.Forms.ToolStripButton bSIT_StudentsToolStripButton;
        private System.Windows.Forms.ToolStrip address_SamalToolStrip;
        private System.Windows.Forms.ToolStripButton address_SamalToolStripButton;
        private System.Windows.Forms.ToolStrip second_Year_StudentsToolStrip;
        private System.Windows.Forms.ToolStripButton second_Year_StudentsToolStripButton;
        private System.Windows.Forms.ToolStrip lastnames_Start_with_A_and_CToolStrip;
        private System.Windows.Forms.ToolStripButton lastnames_Start_with_A_and_CToolStripButton;
        private System.Windows.Forms.ToolStrip firstnames_Start_with_Consotant_LettersToolStrip;
        private System.Windows.Forms.ToolStripButton firstnames_Start_with_Consotant_LettersToolStripButton;
        private System.Windows.Forms.ToolStrip section_2BToolStrip;
        private System.Windows.Forms.ToolStripButton section_2BToolStripButton;
        private System.Windows.Forms.ToolStrip rEFRESH1ToolStrip;
        private System.Windows.Forms.ToolStripButton rEFRESH1ToolStripButton;
    }
}

