﻿

namespace BasicOperations_Sarmiento
{
    class Remainder
    {
        public void ComputeRemainder()
        {
            DeclareVar.remainder = DeclareVar.num1 % DeclareVar.num2;
            System.Console.WriteLine( "\n\tThe Remainder is " + DeclareVar.remainder);
        }
    }
}
