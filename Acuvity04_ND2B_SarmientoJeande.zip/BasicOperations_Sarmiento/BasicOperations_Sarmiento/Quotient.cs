﻿
namespace BasicOperations_Sarmiento
{
    class Quotient
    {
        public void ComputeQuotient()
        {
            DeclareVar.qoutient = DeclareVar.num1 / DeclareVar.num2;
            System.Console.WriteLine("\n\tThe Quotient is " + DeclareVar.qoutient);
        }
    }
}
