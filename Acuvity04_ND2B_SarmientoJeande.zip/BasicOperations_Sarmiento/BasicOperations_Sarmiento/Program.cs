﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations_Sarmiento
{
    class Program
    {
        static void Main(string[] args)
        {
            Input i = new Input();
            i.InputData();

            
            Sum s = new Sum();
            s.ComputeSum();

            Difference d = new Difference();
            d.ComputeDifference();

            Product p = new Product();
            p.ComputeProduct();
           
            Quotient q = new Quotient();
            q.ComputeQuotient();
            Remainder r = new Remainder();
            r.ComputeRemainder();
           

            Console.ReadLine();

            Console.ReadKey();
        }
    }
}
