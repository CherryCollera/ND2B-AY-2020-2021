﻿using System;
using System.Collections.Generic;


namespace BasicOperations_Sarmiento
{
    class Sum
    {
        public void ComputeSum()
        {
     
            DeclareVar.sum = DeclareVar.num1 + DeclareVar.num2;
            System.Console.WriteLine("\n\tThe Sum is " + DeclareVar.sum);
            
        }
    }
}
