﻿

namespace BasicOperations_Sarmiento
{
    class DeclareVar
    {
        public static int num1, num2, sum, difference, product, qoutient, remainder;
    }
}
