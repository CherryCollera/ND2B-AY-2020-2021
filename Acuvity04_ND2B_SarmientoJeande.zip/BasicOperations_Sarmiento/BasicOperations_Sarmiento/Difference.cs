﻿

namespace BasicOperations_Sarmiento
{
    class Difference
    {
        public void ComputeDifference()
        {
            DeclareVar.difference = DeclareVar.num1 - DeclareVar.num2;
            System.Console.WriteLine("\n\tThe Difference is " + DeclareVar.difference);
        }
    }
}
