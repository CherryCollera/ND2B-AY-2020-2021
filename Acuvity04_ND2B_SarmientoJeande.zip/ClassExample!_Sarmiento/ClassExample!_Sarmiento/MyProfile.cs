﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassExample__Sarmiento
{
    class MyProfile
    {
        public void DisplayProfile() 
        {
            Console.WriteLine("\n\n\n\t\tP R O F I L E");
            Console.WriteLine("\nName        :\tJeande P. Sarmiento");
            Console.WriteLine("\nBirthday    :\tFeb 09, 2001");
            Console.WriteLine("\nCourse      :\tBS in Computer Science Major in " + "Network " + "and Data Communication");
            Console.WriteLine("\nYear        :\t2nd Year");
            Console.WriteLine("\nSection     :\tB");
            Console.ReadLine();
            Console.ReadKey();
        }
    }
}
