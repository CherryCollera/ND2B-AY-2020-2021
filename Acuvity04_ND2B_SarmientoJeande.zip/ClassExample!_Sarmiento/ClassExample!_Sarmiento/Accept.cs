﻿

namespace ClassExample__Sarmiento
{
    class Accept
    {
        public string firstname, lastname;
        public void AcceptDetails()
        {
            System.Console.WriteLine("Enter your firstname and lastname: ");
            firstname = System.Console.ReadLine();
            lastname = System.Console.ReadLine();
        }
    }
}
