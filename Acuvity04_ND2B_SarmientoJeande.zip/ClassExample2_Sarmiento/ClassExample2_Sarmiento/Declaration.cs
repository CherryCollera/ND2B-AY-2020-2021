﻿

namespace ClassExample2_Sarmiento
{
    class Declaration
    {
        public string Color
        {
            get
            {
                return Color;
            }

            set
            {
                Color = value;
            }
        }
    }
}
