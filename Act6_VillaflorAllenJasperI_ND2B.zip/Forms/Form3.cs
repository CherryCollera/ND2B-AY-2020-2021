﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Form1
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int num1, num2, sum;

            num1 = Convert.ToInt32(textBox1.Text);
            num2 = Convert.ToInt32(textBox2.Text);

            sum = num1 + num2;
            MessageBox.Show("The Sum is " + Convert.ToString(sum));
        }

        private void Integer_Click(object sender, EventArgs e)
        {
            int number = 15;
            MessageBox.Show(number.ToString());
        }

        private void Float_Click_1(object sender, EventArgs e)
        {
            float number = 15.28f;
            MessageBox.Show(number.ToString());
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            double number = 15.3449;
            MessageBox.Show(number.ToString());
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            this.Hide();
            form1.Show();
        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            Calculator calc = new Calculator();
            calc.Show();
            this.Hide();
        }

        private void button1_Click_3(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click_4(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
        }
    }
}
