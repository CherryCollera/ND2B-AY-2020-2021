﻿
namespace Form1
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Integer = new System.Windows.Forms.Button();
            this.ComputeSum = new System.Windows.Forms.Button();
            this.Float = new System.Windows.Forms.Button();
            this.Double = new System.Windows.Forms.Button();
            this.FirstNumber = new System.Windows.Forms.Label();
            this.SecondNumber = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.Form1 = new System.Windows.Forms.Button();
            this.Calculator = new System.Windows.Forms.Button();
            this.Exit = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Integer
            // 
            this.Integer.BackColor = System.Drawing.SystemColors.Info;
            this.Integer.Location = new System.Drawing.Point(12, 72);
            this.Integer.Name = "Integer";
            this.Integer.Size = new System.Drawing.Size(200, 54);
            this.Integer.TabIndex = 0;
            this.Integer.Text = "Integer";
            this.Integer.UseVisualStyleBackColor = false;
            this.Integer.Click += new System.EventHandler(this.Integer_Click);
            // 
            // ComputeSum
            // 
            this.ComputeSum.BackColor = System.Drawing.SystemColors.Info;
            this.ComputeSum.Location = new System.Drawing.Point(12, 12);
            this.ComputeSum.Name = "ComputeSum";
            this.ComputeSum.Size = new System.Drawing.Size(200, 54);
            this.ComputeSum.TabIndex = 1;
            this.ComputeSum.Text = "Compute Sum";
            this.ComputeSum.UseVisualStyleBackColor = false;
            this.ComputeSum.Click += new System.EventHandler(this.button1_Click);
            // 
            // Float
            // 
            this.Float.BackColor = System.Drawing.SystemColors.Info;
            this.Float.Location = new System.Drawing.Point(12, 132);
            this.Float.Name = "Float";
            this.Float.Size = new System.Drawing.Size(200, 54);
            this.Float.TabIndex = 2;
            this.Float.Text = "Float";
            this.Float.UseVisualStyleBackColor = false;
            this.Float.Click += new System.EventHandler(this.Float_Click_1);
            // 
            // Double
            // 
            this.Double.BackColor = System.Drawing.SystemColors.Info;
            this.Double.Location = new System.Drawing.Point(12, 192);
            this.Double.Name = "Double";
            this.Double.Size = new System.Drawing.Size(200, 54);
            this.Double.TabIndex = 3;
            this.Double.Text = "Double";
            this.Double.UseVisualStyleBackColor = false;
            this.Double.Click += new System.EventHandler(this.button2_Click);
            // 
            // FirstNumber
            // 
            this.FirstNumber.AutoSize = true;
            this.FirstNumber.BackColor = System.Drawing.Color.Transparent;
            this.FirstNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FirstNumber.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.FirstNumber.Location = new System.Drawing.Point(244, 84);
            this.FirstNumber.Name = "FirstNumber";
            this.FirstNumber.Size = new System.Drawing.Size(148, 25);
            this.FirstNumber.TabIndex = 4;
            this.FirstNumber.Text = "First Number: ";
            this.FirstNumber.Click += new System.EventHandler(this.label1_Click);
            // 
            // SecondNumber
            // 
            this.SecondNumber.AutoSize = true;
            this.SecondNumber.BackColor = System.Drawing.Color.Transparent;
            this.SecondNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SecondNumber.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.SecondNumber.Location = new System.Drawing.Point(246, 151);
            this.SecondNumber.Name = "SecondNumber";
            this.SecondNumber.Size = new System.Drawing.Size(180, 25);
            this.SecondNumber.TabIndex = 5;
            this.SecondNumber.Text = "Second Number: ";
            this.SecondNumber.Click += new System.EventHandler(this.label2_Click);
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(450, 84);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(281, 38);
            this.textBox1.TabIndex = 6;
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(450, 151);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(281, 38);
            this.textBox2.TabIndex = 7;
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // Form1
            // 
            this.Form1.BackColor = System.Drawing.SystemColors.Info;
            this.Form1.Location = new System.Drawing.Point(12, 281);
            this.Form1.Name = "Form1";
            this.Form1.Size = new System.Drawing.Size(200, 55);
            this.Form1.TabIndex = 8;
            this.Form1.Text = "Back to Form 1";
            this.Form1.UseVisualStyleBackColor = false;
            this.Form1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // Calculator
            // 
            this.Calculator.BackColor = System.Drawing.SystemColors.Info;
            this.Calculator.Location = new System.Drawing.Point(226, 281);
            this.Calculator.Name = "Calculator";
            this.Calculator.Size = new System.Drawing.Size(200, 55);
            this.Calculator.TabIndex = 9;
            this.Calculator.Text = "Calculator";
            this.Calculator.UseVisualStyleBackColor = false;
            this.Calculator.Click += new System.EventHandler(this.button1_Click_2);
            // 
            // Exit
            // 
            this.Exit.BackColor = System.Drawing.SystemColors.Info;
            this.Exit.Location = new System.Drawing.Point(531, 281);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(200, 55);
            this.Exit.TabIndex = 10;
            this.Exit.Text = "Exit";
            this.Exit.UseVisualStyleBackColor = false;
            this.Exit.Click += new System.EventHandler(this.button1_Click_3);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.Info;
            this.button1.Location = new System.Drawing.Point(492, 208);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(200, 38);
            this.button1.TabIndex = 11;
            this.button1.Text = "Clear";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_4);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Form1.Properties.Resources._31;
            this.ClientSize = new System.Drawing.Size(757, 348);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Exit);
            this.Controls.Add(this.Calculator);
            this.Controls.Add(this.Form1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.SecondNumber);
            this.Controls.Add(this.FirstNumber);
            this.Controls.Add(this.Double);
            this.Controls.Add(this.Float);
            this.Controls.Add(this.ComputeSum);
            this.Controls.Add(this.Integer);
            this.Name = "Form3";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Integer;
        private System.Windows.Forms.Button ComputeSum;
        private System.Windows.Forms.Button Float;
        private System.Windows.Forms.Button Double;
        private System.Windows.Forms.Label FirstNumber;
        private System.Windows.Forms.Label SecondNumber;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button Form1;
        private System.Windows.Forms.Button Calculator;
        private System.Windows.Forms.Button Exit;
        private System.Windows.Forms.Button button1;
    }
}