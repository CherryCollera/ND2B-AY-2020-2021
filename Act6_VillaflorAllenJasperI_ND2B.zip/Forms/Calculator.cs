﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Form1
{
    public partial class Calculator : Form
    {
        double total1 = 0;
        double total2 = 0;
        bool Add = false;
        bool ButtonMinus = false;
        bool Multi = false;
        bool Div = false;
        public Calculator()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "1";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "2";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "3";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "4";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "5";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "6";
        }

        private void button7_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "7";
        }

        private void button8_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "8";
        }

        private void button9_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "9";
        }

        private void dot_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + ".";
        }

        private void button0_Click_1(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "0";
        }

        private void Clear_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
        }

        private void Division_Click(object sender, EventArgs e)
        {
            total1 = total1 + Convert.ToDouble(textBox1.Text);
            textBox1.Clear();

            Add = false;
            ButtonMinus = false;
            Multi = false;
            Div = true;
        }

        private void Multiplication_Click(object sender, EventArgs e)
        {
            total1 = total1 + Convert.ToDouble(textBox1.Text);
            textBox1.Clear();

            Add = false;
            ButtonMinus = false;
            Multi = true;
            Div = false;
        }

        private void Minus_Click(object sender, EventArgs e)
        {
            total1 = total1 + Convert.ToDouble(textBox1.Text);
            textBox1.Clear();

            Add = false;
            ButtonMinus = true;
            Multi = false;
            Div = false;
        }

        private void Addition_Click(object sender, EventArgs e)
        {
            total1 = total1 + Convert.ToDouble(textBox1.Text);
            textBox1.Clear();

            Add = true;
            ButtonMinus = false;
            Multi = false;
            Div = false;
        }

        private void Form1_Click(object sender, EventArgs e)
        {
            Form1 Form1 = new Form1();
            this.Hide();
            Form1.Show();
        }

        private void Form3_Click(object sender, EventArgs e)
        {
            Form3 Form3 = new Form3();
            this.Hide();
            Form3.Show();
        }
      private void Calculator_Load(object sender, EventArgs e)
        {

        }

        private void Equal_Click(object sender, EventArgs e)
        {
            if (Add == true)
            {
                total2 = total1 + double.Parse(textBox1.Text);
            }
            else if (ButtonMinus == true)
            {
                total2 = total1 - double.Parse(textBox1.Text);
            }
            else if (Multi == true)
            {
                total2 = total1 * double.Parse(textBox1.Text);

            }
            else if (Div == true)
            {
                total2 = total1 / double.Parse(textBox1.Text);

            }
            textBox1.Text = total2.ToString(); total1 = 0;
        }

    }
}
