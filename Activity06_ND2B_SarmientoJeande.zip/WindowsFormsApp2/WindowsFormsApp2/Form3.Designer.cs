﻿
namespace WindowsFormsApp2
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Integer = new System.Windows.Forms.Button();
            this.Float = new System.Windows.Forms.Button();
            this.Double = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.ComputeSum = new System.Windows.Forms.Button();
            this.BacktoForm1 = new System.Windows.Forms.Button();
            this.GoToCalculator = new System.Windows.Forms.Button();
            this.Exit = new System.Windows.Forms.Button();
            this.Clear = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Integer
            // 
            this.Integer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Integer.Font = new System.Drawing.Font("Lucida Calligraphy", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Integer.Location = new System.Drawing.Point(11, 12);
            this.Integer.Name = "Integer";
            this.Integer.Size = new System.Drawing.Size(154, 34);
            this.Integer.TabIndex = 0;
            this.Integer.Text = "Integer";
            this.Integer.UseVisualStyleBackColor = false;
            this.Integer.Click += new System.EventHandler(this.Integer_Click);
            // 
            // Float
            // 
            this.Float.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Float.Font = new System.Drawing.Font("Lucida Calligraphy", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Float.Location = new System.Drawing.Point(171, 12);
            this.Float.Name = "Float";
            this.Float.Size = new System.Drawing.Size(154, 34);
            this.Float.TabIndex = 1;
            this.Float.Text = "Float";
            this.Float.UseVisualStyleBackColor = false;
            this.Float.Click += new System.EventHandler(this.Float_Click);
            // 
            // Double
            // 
            this.Double.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Double.Font = new System.Drawing.Font("Lucida Calligraphy", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Double.Location = new System.Drawing.Point(331, 12);
            this.Double.Name = "Double";
            this.Double.Size = new System.Drawing.Size(154, 34);
            this.Double.TabIndex = 2;
            this.Double.Text = "Double";
            this.Double.UseVisualStyleBackColor = false;
            this.Double.Click += new System.EventHandler(this.Double_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Lucida Calligraphy", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(24, 84);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(184, 21);
            this.label1.TabIndex = 3;
            this.label1.Text = "Enter First Number:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Lucida Calligraphy", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(7, 123);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(201, 21);
            this.label2.TabIndex = 4;
            this.label2.Text = "Enter Second Number:";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(223, 84);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(262, 30);
            this.textBox1.TabIndex = 5;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(223, 123);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(262, 30);
            this.textBox2.TabIndex = 6;
            // 
            // ComputeSum
            // 
            this.ComputeSum.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ComputeSum.Font = new System.Drawing.Font("Lucida Calligraphy", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ComputeSum.Location = new System.Drawing.Point(223, 173);
            this.ComputeSum.Name = "ComputeSum";
            this.ComputeSum.Size = new System.Drawing.Size(154, 34);
            this.ComputeSum.TabIndex = 7;
            this.ComputeSum.Text = "Compute Sum";
            this.ComputeSum.UseVisualStyleBackColor = false;
            this.ComputeSum.Click += new System.EventHandler(this.ComputeSum_Click);
            // 
            // BacktoForm1
            // 
            this.BacktoForm1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.BacktoForm1.Font = new System.Drawing.Font("Lucida Calligraphy", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BacktoForm1.Location = new System.Drawing.Point(11, 231);
            this.BacktoForm1.Name = "BacktoForm1";
            this.BacktoForm1.Size = new System.Drawing.Size(180, 26);
            this.BacktoForm1.TabIndex = 8;
            this.BacktoForm1.Text = "Back to Form 1";
            this.BacktoForm1.UseVisualStyleBackColor = false;
            this.BacktoForm1.Click += new System.EventHandler(this.BacktoForm1_Click);
            // 
            // GoToCalculator
            // 
            this.GoToCalculator.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.GoToCalculator.Font = new System.Drawing.Font("Lucida Calligraphy", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GoToCalculator.Location = new System.Drawing.Point(197, 231);
            this.GoToCalculator.Name = "GoToCalculator";
            this.GoToCalculator.Size = new System.Drawing.Size(180, 26);
            this.GoToCalculator.TabIndex = 9;
            this.GoToCalculator.Text = "Go To Calculator";
            this.GoToCalculator.UseVisualStyleBackColor = false;
            this.GoToCalculator.Click += new System.EventHandler(this.GoToCalculator_Click);
            // 
            // Exit
            // 
            this.Exit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.Exit.Font = new System.Drawing.Font("Lucida Calligraphy", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Exit.Location = new System.Drawing.Point(383, 231);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(116, 26);
            this.Exit.TabIndex = 10;
            this.Exit.Text = "Exit";
            this.Exit.UseVisualStyleBackColor = false;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // Clear
            // 
            this.Clear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Clear.Font = new System.Drawing.Font("Lucida Calligraphy", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Clear.Location = new System.Drawing.Point(383, 173);
            this.Clear.Name = "Clear";
            this.Clear.Size = new System.Drawing.Size(102, 34);
            this.Clear.TabIndex = 11;
            this.Clear.Text = "Clear";
            this.Clear.UseVisualStyleBackColor = false;
            this.Clear.Click += new System.EventHandler(this.Clear_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::WindowsFormsApp2.Properties.Resources.tumblr_n5iz4n4dNf1qblgjco1_500;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(511, 268);
            this.ControlBox = false;
            this.Controls.Add(this.Clear);
            this.Controls.Add(this.Exit);
            this.Controls.Add(this.GoToCalculator);
            this.Controls.Add(this.BacktoForm1);
            this.Controls.Add(this.ComputeSum);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Double);
            this.Controls.Add(this.Float);
            this.Controls.Add(this.Integer);
            this.Name = "Form3";
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Integer;
        private System.Windows.Forms.Button Float;
        private System.Windows.Forms.Button Double;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button ComputeSum;
        private System.Windows.Forms.Button BacktoForm1;
        private System.Windows.Forms.Button GoToCalculator;
        private System.Windows.Forms.Button Exit;
        private System.Windows.Forms.Button Clear;
    }
}