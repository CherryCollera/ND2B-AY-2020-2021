﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Calculator : Form
    {
        double total1 = 0;
        double total2 = 0;
        bool buttonPlusClick = false;
        bool buttonMinusClick = false;
        bool buttonMultiClick = false;
        bool buttonDivClick = false;
        public Calculator()
        {
            InitializeComponent();
        }

       
         
        private void buttonBackForm1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            this.Hide();
            form1.Show();
        }

        private void buttonGotoForm3_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            this.Hide();
            form3.Show();

        }
        private void buttonPlus_Click(object sender, EventArgs e)
        {
            total1 = total1 + Convert.ToDouble(textBox1.Text);
            textBox1.Clear();

            buttonPlusClick = true;
            buttonMinusClick = false;
            buttonMultiClick = false;
            buttonDivClick = false;
        }
       
        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "1";

        } 
        private void button2_Click_1(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "2";
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "3";
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "4";
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "5";
        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "6";
        }

        private void button7_Click_1(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "7";
        }

        private void button8_Click_1(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "8";
        }

        private void button9_Click_1(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "9";
        }

        private void button0_Click_1(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "0";
        }

        private void buttonDot_Click_1(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + ".";
        }

        private void Clear_Click_1(object sender, EventArgs e)
        {
            textBox1.Clear();
        }

        private void buttonMinus_Click_1(object sender, EventArgs e)
        {
            total1 = total1 + Convert.ToDouble(textBox1.Text);
            textBox1.Clear();

            buttonPlusClick = false;
            buttonMinusClick = true;
            buttonMultiClick = false;
            buttonDivClick = false;
        }

        private void buttonMulti_Click_1(object sender, EventArgs e)
        {
            total1 = total1 + Convert.ToDouble(textBox1.Text);
            textBox1.Clear();

            buttonPlusClick = false;
            buttonMinusClick = false;
            buttonMultiClick = true;
            buttonDivClick = false;
        }

        private void buttonDiv_Click_1(object sender, EventArgs e)
        {
            total1 = total1 + Convert.ToDouble(textBox1.Text);
            textBox1.Clear();

            buttonPlusClick = false;
            buttonMinusClick = false;
            buttonMultiClick = false;
            buttonDivClick = true;
        }

        private void buttonEqual_Click_1(object sender, EventArgs e)
        {
            if (buttonPlusClick == true)
            {
                total2 = total1 + double.Parse(textBox1.Text);
            }
            else if (buttonMinusClick == true)
            {
                total2 = total1 - double.Parse(textBox1.Text);
            }
            else if (buttonMultiClick == true)
            {
                total2 = total1 * double.Parse(textBox1.Text);

            }
            else if (buttonDivClick == true)
            {
                total2 = total1 / double.Parse(textBox1.Text);

            }
            textBox1.Text = total2.ToString(); total1 = 0;
        
        }
    }
}
