﻿using System;

namespace For
{
    class Program
    {
        static void Main(string[] args)
        {
            for(int a = 10 - 1; a >= 0; a--){
                Console.WriteLine(a);
            }
            Console.ReadKey();
        }
    }
}
