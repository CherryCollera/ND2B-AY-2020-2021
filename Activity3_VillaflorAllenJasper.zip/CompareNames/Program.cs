﻿using System;

namespace Activity3
{
    class Program
    {
        static void Main(string[] args)
        {
			String string1 = "Allin";
			String string2 = "Allin";
			String string3 = "Allen";
			String string4 = "Allen";
			String string5 = "ALLEN JASPER";


			Console.WriteLine("Using Equals() method");

			Console.WriteLine("	Compare {0} to {1}: {2}", string1, string2, String.Equals(string1, string2));
			Console.WriteLine("	Compare {0} to {1}: {2}", string1, string3, String.Equals(string1, string3));
			Console.WriteLine("Length of {0} is {1} ", string1, string1.Length);
			Console.WriteLine("String {0} Substring(0, 3) will return {1}", string5, string5.Substring(0, 8));

			Console.WriteLine("Using Compare() method");

			Console.WriteLine("	Compare {0} to {1}: {2}", string1, string2, String.Compare(string1, string2));
			Console.WriteLine("	Compare {0} to {1}: {2}", string1, string3, String.Compare(string1, string3));
			Console.WriteLine("	Compare {0} to {1}: {2}", string3, string1, String.Compare(string3, string1));
			Console.WriteLine("	Compare {0} to {1}: {2}", string4, string5, String.Compare(string4, string5));

			Console.WriteLine("Using CompareTo() method");

			Console.WriteLine(" Compare {0} to {1}: {2}", string1, string2, string1.CompareTo(string2));
			Console.WriteLine(" Compare {0} to {1}: {2}", string1, string3, string1.CompareTo(string3));
			Console.WriteLine(" Compare {0} to {1}: {2}", string3, string1, string3.CompareTo(string1));
		}
    }
}
