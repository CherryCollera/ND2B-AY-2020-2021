﻿// in this program it will add all numbers that are inside the num variable
using System;

namespace DoWhile
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] num = new int[] { 6, 7, 8, 10 };
            int sum = 0;
            int a = 0;
            do
            {
                sum += num[a];
                a++;
            } while (a < 4);

            Console.WriteLine(sum);
            Console.ReadKey();

           
        }
    }
}
