﻿using System;

namespace CompareNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter 1st Number: ");
            int a = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter 2nd Number: ");
            int j = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter 3rd Number: ");
            int v = Convert.ToInt32(Console.ReadLine());

            
             if (a > j)
            {
                if (a > v)
                {
                    Console.WriteLine("{0} is greater than {1} and {2}", a, j, v);

                    Console.WriteLine("{0} is greater than {1}", a, j);
                    Console.WriteLine("{0} is greater than {1}", a, v);
                    Console.ReadKey();
                }
                
            }
            else if (j > v)
            {
                if (j > a)
                {
                    Console.WriteLine("{0} is greater than {1} and {2}", j, a, v);
                    Console.WriteLine("{0} is greater than {1}", j, v);
                    Console.WriteLine("{0} is greater than {1}", j, a);
                    Console.ReadKey();
                }
            }
            else if (v > a)
            {
                if (v > j)
                {
                    Console.WriteLine("{0} greater than {1} and {2}", v, j, a);

                    Console.WriteLine("{0} greater than {1}", v, a);
                    Console.WriteLine("{0} is greater than {1}", v, j);
                    Console.ReadKey();
                }
            }
        }
    }
}
