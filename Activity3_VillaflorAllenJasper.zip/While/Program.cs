﻿/* In this program it will print while statement that will start in 1 and then it will stop until it reaches
its goal which is 10*/
using System;

namespace While
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 0;
           while(a <= 10)
            {
                Console.WriteLine("While Statement");
                Console.WriteLine(a);
                a++;
            }
            Console.ReadKey();
        }
    }
}
