﻿using System;

namespace Switch
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Name: ");
            String Name = Console.ReadLine();
            Console.WriteLine("Enter Gender: ");
            Char Gender = Convert.ToChar(Console.ReadLine());

            switch (Gender)
            {
                case 'M': case 'm':
                    Console.WriteLine("\n "+ Name + "!" + " Your gender is Male!");
                    break;
                case 'F': case 'f':
                    Console.WriteLine("\n " + Name + "!" + " Your gender is Female!");
                    break;
                default:
                    Console.WriteLine("\nInvalid Input... Try Again... ");
                    break;
            }
            Console.ReadKey();
        }
    }
}
