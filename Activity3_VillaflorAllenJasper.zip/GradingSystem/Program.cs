﻿using System;

namespace GradingSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Final Grade: ");
            int grade = Convert.ToInt32(Console.ReadLine());

            if (grade>=98)
            {
                Console.WriteLine("Grade Equivaent: 1.00");
                Console.WriteLine("Remarks: Excellent");
            }
            else if(grade>=95)
            {
                Console.WriteLine("Grade Equivaent: 1.25");
                Console.WriteLine("Remarks: Excellent");
            }
            else if (grade>=92)
            {
                Console.WriteLine("Grade Equivaent: 1.50");
                Console.WriteLine("Remarks: Very Good");
            }
            else if (grade>=89)
            {
                Console.WriteLine("Grade Equivaent: 1.75");
                Console.WriteLine("Remarks: Very Good");
            }
            else if (grade>=86)
            {
                Console.WriteLine("Grade Equivaent: 2.00");
                Console.WriteLine("Remarks: Good");
            }
            else if (grade>=83)
            {
                Console.WriteLine("Grade Equivaent: 2.25");
                Console.WriteLine("Remarks: Good");
            }
            else if (grade>=80)
            {
                Console.WriteLine("Grade Equivaent: 2.50");
                Console.WriteLine("Remarks: Fair");
            }
            else if (grade>=77)
            {
                Console.WriteLine("Grade Equivaent: 2.75");
                Console.WriteLine("Remarks: Passed");
            }
            else if (grade>=75)
            {
                Console.WriteLine("Grade Equivaent: 3.00");
                Console.WriteLine("Remarks: Passed");
            }
            else if (grade>=72)
            {
                Console.WriteLine("Grade Equivaent: 4.00");
                Console.WriteLine("Remarks: Conditional");
            }
            else if (grade<=71 || grade==60)
            {
                Console.WriteLine("Grade Equivaent: 5.00");
                Console.WriteLine("Remarks: Failed");
            }
            else
            {
                Console.WriteLine("Incomplete");
            }
            Console.ReadKey();
        }
    }
}
