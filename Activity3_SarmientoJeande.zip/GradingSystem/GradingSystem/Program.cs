﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GradingSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            int grade;
            double[] equi = { 1.00, 1.25, 1.50, 1.75, 2.00, 2.25, 2.50, 2.75, 3.00, 4.00, 5.00 };
            String[] remarks = { "Excellent", "Very Good ", "Good", "Fair", "Passed", " Conditional (MT only)", "Failed" };
            String inc = "INC";

            Console.WriteLine("Enter your Final grade here:  ");
            grade = Convert.ToInt32(Console.ReadLine());


            if ((grade >= 98) && (grade <= 100))
            {
                Console.WriteLine("Grade Equivalent: " + equi[0] + "\nRemarks: " + remarks[0]);
            }

            else if ((grade >= 95) && (grade <= 97))
            {
                Console.WriteLine("Grade Equivalent: " + equi[1] + "\nRemarks: " + remarks[0]);

            }

            else if ((grade >= 92) && (grade <= 94))
            {
                Console.WriteLine("Grade Equivalent: " + equi[2] + "\nRemarks: " + remarks[1]);
            }

            else if ((grade >= 91) && (grade <= 89))
            {
                Console.WriteLine("Grade Equivalent: " + equi[3] + "\nRemarks: " + remarks[1]);
            }

            else if ((grade >= 86) && (grade <= 88))
            {
                Console.WriteLine("Grade Equivalent: " + equi[4] + "\nRemarks : " + remarks[2]);
            }

            else if ((grade >= 83) && (grade <= 85))
            {
                Console.WriteLine("Grade Equivalent: " + equi[5] + "\nRemarks : " + remarks[2]);
            }

            else if ((grade >= 80) && (grade <= 82))
            {
                Console.WriteLine("Grade Equivalent: " + equi[6] + "\nRemarks : " + remarks[3]);
                Console.ReadKey();
            }

            else if ((grade >= 77) && (grade <= 79))
            {
                Console.WriteLine("Grade Equivalent: " + equi[7] + "\nRemarks : " + remarks[3]);
                Console.ReadKey();
            }

            else if ((grade >= 75) && (grade <= 76))
            {
                Console.WriteLine("Grade Equivalent: " + equi[8] + "\nRemarks : " + remarks[4]);
                Console.ReadKey();
            }
            else if ((grade >= 72) && (grade <= 74))
            {
                Console.WriteLine("Grade Equivalent: " + equi[9] + "\nRemarks : " + remarks[5]);
            }
            else if ((grade >= 60) && (grade <= 71))
            {
                Console.WriteLine("Grade Equivalent: " + equi[10] + "\nRemarks : " + remarks[6]);
                Console.ReadKey();
            }
            else
                Console.WriteLine("Grade Equivalent: " + inc);
            Console.ReadKey();
        }
        }
}
