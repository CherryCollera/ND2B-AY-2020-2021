﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace For
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int JPS09 = 10 - 1; JPS09 >= 0; JPS09--)
            {
                Console.WriteLine(JPS09);
            }
            Console.ReadLine();
        }
    }
}
