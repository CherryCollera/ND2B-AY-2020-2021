﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Do_while
{
    class Sarmiento_Jeande_ND2B
    {
        static void Main(string[] args)
        {
            int[] JPS09_nms = new int [] { 6, 7, 8, 10 };
            int JPS09_sum =  0;
            int JPS_i = 0;

            do
            {
                JPS09_sum += JPS09_nms[JPS_i];
                JPS_i++;
            }
            while (JPS_i < 4);
            Console.WriteLine(JPS09_sum);
            Console.ReadKey();
        }
    }
}
