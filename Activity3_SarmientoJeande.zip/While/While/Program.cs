﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace While
{
    class Sarmiento_Jeande_ND2B
    {
        static void Main(string[] args)
        {
            int JPS09 = 0;
            while (JPS09 <= 10)
            {
                Console.Write("While statement ");
                Console.WriteLine(JPS09);
                JPS09++;
            }
            Console.ReadKey();
        }
    }
}
