﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Switch
{
    class Sarmiento_Jeande_ND2B
    {
        static void Main(string[] args)
        {
            string JPS09_name;
            char JPS09_gender;

            Console.Write("Enter your name: ");
            JPS09_name = Console.ReadLine();

            Console.Write("Enter your Gender M / F: ");
            JPS09_gender=Convert.ToChar(Console.ReadLine());

            switch (JPS09_gender) 
            {
                case 'M': case 'm':
                    Console.WriteLine("\nHi " + JPS09_name + " !" + " Your gender is Male!.");
                    break;
          
                case 'F': case 'f':
                    Console.WriteLine("\nHi " + JPS09_name + " !" + " Your gender is Female!.");
                    break;

                default:
                    Console.WriteLine("\nInvalid input.... Try again....");
                    break;
             }Console.ReadKey();

        }
    }
}
