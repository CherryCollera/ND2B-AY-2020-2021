﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompareNumbers
{
    class Sarmiento_Jeande_ND2B
    {
        static void Main(string[] args)
        {
            int JPS09_num1,JPS09_num2, JPS09_num3;

            Console.Write("   Enter 1st number: ");
            JPS09_num1 = Convert.ToInt32(Console.ReadLine());

            Console.Write("   Enter 2nd number: ");
            JPS09_num2 = Convert.ToInt32(Console.ReadLine());

            Console.Write("   Enter 3rd number: ");
            JPS09_num3 = Convert.ToInt32(Console.ReadLine());

            if ((JPS09_num1 == JPS09_num2) && JPS09_num1 > JPS09_num3)
            {
                Console.Write(" \n{0} and {1} are greater than {2} \n {2} is less than {0} \n {1} is less than {0}", JPS09_num1, JPS09_num2, JPS09_num3);
               
            }

            else if ((JPS09_num1 == JPS09_num3) && JPS09_num1 > JPS09_num2)
            {
                Console.Write(" \n{0} and {2} are greater than {1} \n {2} is less than {0} \n {1} is less than {0}", JPS09_num1, JPS09_num2, JPS09_num3);
               
            }

            else if ((JPS09_num2 == JPS09_num3) && JPS09_num2 > JPS09_num1)
            {
                Console.Write(" \n{1} and {2} are greater than {0}\n {0} is less than {1} \n {2} is less than {1}", JPS09_num1, JPS09_num2, JPS09_num3);
               
            }

            else if ((JPS09_num3 > JPS09_num2) && JPS09_num3 > JPS09_num1)
            {
                Console.Write(" \n{2} are greater than {0} and {1} \n {0} is less than {2} \n {1} is less than {2}", JPS09_num1, JPS09_num2, JPS09_num3);
                
            }
            else if ((JPS09_num2 > JPS09_num1) && JPS09_num2 > JPS09_num3)
            {
                Console.Write(" \n{1} are greater than {0} and {2} \n {0} is less than {1} \n {2} is less than {1}", JPS09_num1, JPS09_num2, JPS09_num3);
                
            }
            else if ((JPS09_num1 > JPS09_num2) && JPS09_num1 > JPS09_num3)
            {
                Console.Write(" \n{0} are greater than {1} and {2}\n {2} is less than {0} \n {1} is less than {0}", JPS09_num1, JPS09_num2, JPS09_num3);
               
            }
            else
                Console.Write(" \n{0},{1} and {2} are equal", JPS09_num1, JPS09_num2, JPS09_num3);
               

            

            Console.ReadKey();

        }
    }
}
